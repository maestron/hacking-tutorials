#define	ID_FILE_EXIT   1000
#define	ID_HELP_ABOUT  1001
#define	IDOK           2000
#define	IDEMAIL        2001
#define	IDAZTEK        2003
#define	IDBSRF         2004
