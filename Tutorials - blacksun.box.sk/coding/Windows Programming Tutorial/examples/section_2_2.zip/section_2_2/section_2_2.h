#define WM_TRAYNOTIFY (WM_USER + 1000)
#define IDI_ICON1     1000
#define IDC_TRAYICON  1001
#define IDM_EXIT      1002
#define IDM_ABOUT     1003