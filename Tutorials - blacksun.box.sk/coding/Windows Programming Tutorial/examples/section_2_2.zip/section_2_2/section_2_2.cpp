#include <windows.h>
#include "section_2_2.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

static char gszClassName[]  = "MyWindowClass";
static HINSTANCE ghInstance = NULL;
HMENU hMenu;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
        WNDCLASSEX WndClass;
        HWND hwnd;
        MSG Msg;

        ghInstance = hInstance;

        WndClass.cbSize        = sizeof(WNDCLASSEX);
        WndClass.style         = NULL;
        WndClass.lpfnWndProc   = WndProc;
        WndClass.cbClsExtra    = 0;
        WndClass.cbWndExtra    = 0;
        WndClass.hInstance     = ghInstance;
        WndClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
        WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
        WndClass.lpszMenuName  = NULL;
        WndClass.lpszClassName = gszClassName;
        WndClass.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

        if(!RegisterClassEx(&WndClass)) {
                MessageBox(0, "Window Registration Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        hwnd = CreateWindowEx(
                WS_EX_STATICEDGE,
                gszClassName,
                "Windows Title",
                WS_OVERLAPPEDWINDOW,
                CW_USEDEFAULT, CW_USEDEFAULT,
                320, 240,
                NULL, NULL,
                ghInstance,
                NULL);

        if(hwnd == NULL) {
                MessageBox(0, "Window Creation Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        ShowWindow(hwnd, nCmdShow);
        UpdateWindow(hwnd);

        while(GetMessage(&Msg, NULL, 0, 0)) {
                TranslateMessage(&Msg);
                DispatchMessage(&Msg);
        }
        return Msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
        NOTIFYICONDATA notifyIconData;

        switch(Message) {
                case WM_CREATE:
                        notifyIconData.cbSize           = sizeof(NOTIFYICONDATA);
                        notifyIconData.hWnd             = hwnd;
                        notifyIconData.uID              = IDC_TRAYICON;
                        notifyIconData.uFlags           = NIF_MESSAGE | NIF_ICON | NIF_TIP;
                        notifyIconData.uCallbackMessage = WM_TRAYNOTIFY;
                        notifyIconData.hIcon            = (HICON) LoadImage(
                                                                        ghInstance,
                                                                        MAKEINTRESOURCE(IDI_ICON1),
                                                                        IMAGE_ICON,
                                                                        16, 16,
                                                                        NULL);
                        lstrcpyn(notifyIconData.szTip, "Tray Icon", sizeof(notifyIconData.szTip));
                        Shell_NotifyIcon(NIM_ADD, &notifyIconData);

                        hMenu = CreatePopupMenu();
                        AppendMenu(hMenu, MF_STRING, IDM_EXIT, "E&xit");
                        AppendMenu(hMenu, MF_SEPARATOR, NULL, NULL);
                        AppendMenu(hMenu, MF_STRING, IDM_ABOUT, "&About");
                        break;
                case WM_TRAYNOTIFY:
                        switch(wParam) {
                                case IDC_TRAYICON:
                                        switch(lParam) {
                                                case WM_LBUTTONDOWN:
                                                case WM_RBUTTONDOWN:
                                                        POINT point;

                                                        GetCursorPos(&point);
                                                        SetForegroundWindow(hwnd);
                                                        TrackPopupMenu(hMenu, TPM_RIGHTALIGN, point.x, point.y, NULL, hwnd, NULL);
                                                        SendMessage(hwnd, WM_NULL, NULL, NULL);
                                                        break;
                                        }
                                        break;
                        }
                        break;
                case WM_COMMAND:
                        switch(wParam) {
                                case IDM_EXIT:
                                        SendMessage(hwnd, WM_CLOSE, NULL, NULL);
                                        break;
                                case IDM_ABOUT:
                                        MessageBox(
                                                hwnd,
                                                "Example of a windows system tray program\r\nWritten by AZTEK",
                                                "About",
                                                NULL);
                                        break;
                                        break;
                        }
                        break;
                case WM_CLOSE:
                        DestroyWindow(hwnd);
                        break;
                case WM_DESTROY:
                        notifyIconData.cbSize = sizeof(NOTIFYICONDATA);
                        notifyIconData.hWnd   = hwnd;
                        notifyIconData.uID    = IDC_TRAYICON;
                        Shell_NotifyIcon(NIM_DELETE, &notifyIconData);

                        DestroyMenu(hMenu);

                        PostQuitMessage(0);
                        break;
                default:
                        return DefWindowProc(hwnd, Message, wParam, lParam);
        }
        return 0;
}
