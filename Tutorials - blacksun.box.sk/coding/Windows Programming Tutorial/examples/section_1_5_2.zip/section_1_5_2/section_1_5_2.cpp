#include <windows.h>
#include "section_1_5_2.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

static char g_szClassName[]  = "MyWindowClass";
static HINSTANCE g_hInstance = NULL;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
        WNDCLASSEX WndClass;
        HWND hwnd;
        MSG Msg;

        g_hInstance = hInstance;

        WndClass.cbSize        = sizeof(WNDCLASSEX);
        WndClass.style         = NULL;
        WndClass.lpfnWndProc   = WndProc;
        WndClass.cbClsExtra    = 0;
        WndClass.cbWndExtra    = 0;
        WndClass.hInstance     = g_hInstance;
        WndClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
        WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
        WndClass.lpszMenuName  = NULL;
        WndClass.lpszClassName = g_szClassName;
        WndClass.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

        if(!RegisterClassEx(&WndClass)) {
                MessageBox(0, "Window Registration Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        hwnd = CreateWindowEx(
                WS_EX_STATICEDGE,
                g_szClassName,
                "Windows Title",
                WS_OVERLAPPEDWINDOW,
                CW_USEDEFAULT, CW_USEDEFAULT,
                320, 240,
                NULL, NULL,
                g_hInstance,
                NULL);

        if(hwnd == NULL) {
                MessageBox(0, "Window Creation Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        ShowWindow(hwnd, nCmdShow);
        UpdateWindow(hwnd);

        while(GetMessage(&Msg, NULL, 0, 0)) {
                TranslateMessage(&Msg);
                DispatchMessage(&Msg);
        }
        return Msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
        HMENU hMenu, hSubMenu;

        switch(Message) {
                case WM_CLOSE:
                        DestroyWindow(hwnd);
                        break;
                case WM_DESTROY:
                        PostQuitMessage(0);
                        break;
                case WM_CREATE:
                        hMenu = CreateMenu();

                        hSubMenu = CreatePopupMenu();
                        AppendMenu(hSubMenu, MF_STRING, ID_FILE_NEW, "&New");
                        AppendMenu(hSubMenu, MF_STRING, ID_FILE_OPEN, "&Open");
                        AppendMenu(hSubMenu, MF_STRING, ID_FILE_SAVE, "&Save");
                        AppendMenu(hSubMenu, MF_SEPARATOR, 0, 0);
                        AppendMenu(hSubMenu, MF_STRING, ID_FILE_EXIT, "E&xit");
                        AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu, "&File");

                        hSubMenu = CreatePopupMenu();
                        AppendMenu(hSubMenu, MF_STRING, ID_DO_SOMETHING, "&Something");
                        AppendMenu(hSubMenu, MF_STRING, ID_DO_SOMETHING_ELSE, "Something &Else");
                        AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu, "&Do");

                        hSubMenu = CreatePopupMenu();
                        AppendMenu(hSubMenu, MF_STRING, ID_HELP_ABOUT, "&About");
                        AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu, "&Help");

                        SetMenu(hwnd, hMenu);
                        break;
                case WM_COMMAND:
                        switch(LOWORD(wParam)) {
                                case ID_FILE_NEW:
                                        MessageBox(hwnd, "New File", "Menu", 0);
                                        break;
                                case ID_FILE_OPEN:
                                        MessageBox(hwnd, "Open File", "Menu", 0);
                                        break;
                                case ID_FILE_SAVE:
                                        MessageBox(hwnd, "Save File", "Menu", 0);
                                        break;
                                case ID_FILE_EXIT:
                                        PostQuitMessage(0);
                                case ID_DO_SOMETHING:
                                        MessageBox(hwnd, "Do Something", "Menu", 0);
                                        break;
                                case ID_DO_SOMETHING_ELSE:
                                        MessageBox(hwnd, "Do Something Else", "Menu", 0);
                                        break;
                                case ID_HELP_ABOUT:
                                        MessageBox(hwnd, "Writen By AZTEK", "About", 0);
                                        break;
                        }
                        break;
                default:
                        return DefWindowProc(hwnd, Message, wParam, lParam);
        }
        return 0;
}
