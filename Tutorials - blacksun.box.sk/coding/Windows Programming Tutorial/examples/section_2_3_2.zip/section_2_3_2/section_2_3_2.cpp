#include <windows.h>
#include <commctrl.h>
#include "section_2_3_2.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

static char gszClassName[]  = "MyWindowClass";
static HINSTANCE ghInstance = NULL;
HWND   ghToolBar;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
        WNDCLASSEX WndClass;
        HWND hwnd;
        MSG Msg;

        ghInstance = hInstance;

        WndClass.cbSize        = sizeof(WNDCLASSEX);
        WndClass.style         = NULL;
        WndClass.lpfnWndProc   = WndProc;
        WndClass.cbClsExtra    = 0;
        WndClass.cbWndExtra    = 0;
        WndClass.hInstance     = ghInstance;
        WndClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
        WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
        WndClass.lpszMenuName  = NULL;
        WndClass.lpszClassName = gszClassName;
        WndClass.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

        if(!RegisterClassEx(&WndClass)) {
                MessageBox(0, "Window Registration Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        hwnd = CreateWindowEx(
                WS_EX_STATICEDGE,
                gszClassName,
                "Windows Title",
                WS_OVERLAPPEDWINDOW,
                CW_USEDEFAULT, CW_USEDEFAULT,
                320, 240,
                NULL, NULL,
                ghInstance,
                NULL);

        if(hwnd == NULL) {
                MessageBox(0, "Window Creation Failed!", "Error!", MB_ICONSTOP | MB_OK);
                return 0;
        }

        ShowWindow(hwnd, nCmdShow);
        UpdateWindow(hwnd);

        while(GetMessage(&Msg, NULL, 0, 0)) {
                TranslateMessage(&Msg);
                DispatchMessage(&Msg);
        }
        return Msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
        switch(Message) {
                case WM_CREATE:
                        TBADDBITMAP tbAddBitmap;
                        TBBUTTON tbButton[7];

                        InitCommonControls();

                        ghToolBar = CreateWindowEx(
                                NULL,
                                TOOLBARCLASSNAME,
                                NULL,
                                WS_CHILD | WS_VISIBLE,
                                0, 0,
                                0, 0,
                                hwnd, (HMENU)IDC_TOOLBAR,
                                ghInstance,
                                NULL);
                        SendMessage(ghToolBar, TB_BUTTONSTRUCTSIZE, (WPARAM) sizeof(TBBUTTON), NULL);

                        tbAddBitmap.hInst = HINST_COMMCTRL;
                        tbAddBitmap.nID   = IDB_STD_SMALL_COLOR;
                        SendMessage(ghToolBar, TB_ADDBITMAP, 0, (LPARAM) &tbAddBitmap);

                        ZeroMemory(tbButton, sizeof(tbButton));

                        tbButton[0].iBitmap   = STD_FILENEW;
                        tbButton[0].fsState   = TBSTATE_ENABLED;
                        tbButton[0].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[0].idCommand = IDM_BUTTON0;

                        tbButton[1].iBitmap   = STD_FILEOPEN;
                        tbButton[1].fsState   = TBSTATE_ENABLED;
                        tbButton[1].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[1].idCommand = IDM_BUTTON1;

                        tbButton[2].iBitmap   = STD_FILESAVE;
                        tbButton[2].fsState   = TBSTATE_ENABLED;
                        tbButton[2].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[2].idCommand = IDM_BUTTON2;

                        tbButton[3].fsStyle   = TBSTYLE_SEP;

                        tbButton[4].iBitmap   = STD_CUT;
                        tbButton[4].fsState   = TBSTATE_ENABLED;
                        tbButton[4].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[4].idCommand = IDM_BUTTON3;

                        tbButton[5].iBitmap   = STD_COPY;
                        tbButton[5].fsState   = TBSTATE_ENABLED;
                        tbButton[5].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[5].idCommand = IDM_BUTTON4;

                        tbButton[6].iBitmap   = STD_PASTE;
                        tbButton[6].fsState   = TBSTATE_ENABLED;
                        tbButton[6].fsStyle   = TBSTYLE_BUTTON;
                        tbButton[6].idCommand = IDM_BUTTON5;

                        SendMessage(ghToolBar, TB_ADDBUTTONS, 7, (LPARAM) &tbButton);
                        break;
                case WM_COMMAND:
                        switch(LOWORD(wParam)) {
                                case IDM_BUTTON0:
                                case IDM_BUTTON1:
                                case IDM_BUTTON2:
                                case IDM_BUTTON3:
                                case IDM_BUTTON4:
                                case IDM_BUTTON5:
                                        MessageBox(hwnd, "A Button was clicked.", "Toolbar Message", MB_ICONINFORMATION | MB_OK);
                                        break;
                        }
                        break;
                case WM_SIZE:
                        SendMessage(ghToolBar, TB_AUTOSIZE, 0, 0);
                        break;
                case WM_CLOSE:
                        DestroyWindow(hwnd);
                        break;
                case WM_DESTROY:
                        PostQuitMessage(0);
                        break;
                default:
                        return DefWindowProc(hwnd, Message, wParam, lParam);
        }
        return 0;
} 