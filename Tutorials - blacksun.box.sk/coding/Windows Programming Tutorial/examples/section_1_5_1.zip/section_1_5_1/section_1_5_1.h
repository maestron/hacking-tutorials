#define ID_FILE_NEW           1000
#define ID_FILE_OPEN          1001
#define ID_FILE_SAVE          1002
#define ID_FILE_EXIT          1003
#define ID_DO_SOMETHING       1004
#define ID_DO_SOMETHING_ELSE  1005
#define ID_HELP_ABOUT         1006
